@extends('specialist_doctors_bd.layout.master')

@section('content')
    
    <p>Blog</p>
	
@endsection