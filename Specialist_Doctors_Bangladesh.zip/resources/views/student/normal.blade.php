@extends('student.master')

@section('content')
	
	<h3>I am Normal Page!</h3>

@endsection