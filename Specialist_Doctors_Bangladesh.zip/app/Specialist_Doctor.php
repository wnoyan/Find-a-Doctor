<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Specialist_Doctor extends Model
{
    //
}
