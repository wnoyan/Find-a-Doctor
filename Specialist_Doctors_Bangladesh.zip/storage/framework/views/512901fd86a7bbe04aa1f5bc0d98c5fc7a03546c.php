<div class="container-fluid header mb-2">
        <div class="row header-title">
            <div class="offset-4 col-4">
                <p>Specialist Doctors USA</p>
            </div>
        </div>
        <div class="row header-navbar">
            <div class="col">
                <nav class="navbar navbar-expand-sm  justify-content-center">
                      <button class="navbar-toggler navbar-light" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span class="navbar-toggler-icon"></span>
                      </button>
                      <div class="collapse navbar-collapse justify-content-center" id="collapsibleNavbar">
                          <ul class="navbar-nav">
                            <li class="nav-item">
                              <a class="nav-link" href="/home">Home</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="#">Hospital</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="#">Doctors</a>
                            </li>
                              <li class="nav-item">
                              <a class="nav-link" href="#">Your Area</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="#">Blog</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="#">Contact</a>
                            </li>
                              <li class="nav-item">
                              <a class="nav-link" href="#">Doctor's Registration</a>
                            </li>
                          </ul>
                      </div>  
                </nav>
            </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\Noyan\Specialist_Doctors_Bangladesh\resources\views/specialist_doctors_bd/layout/header.blade.php ENDPATH**/ ?>