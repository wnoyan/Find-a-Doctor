

<?php $__env->startSection('content'); ?>

	<div class="container shadow-lg bg-white mt-2 mb-2">
		<!-- Basic Infos -->
			<div class="row">
	        	<img class="rounded-circle m-3" src="<?php echo e(asset('image/doctor/' . $doctor->image)); ?>" style="width:15%; height:20%;" alt="Doctor Image">
	        	
	        	<div>
	        		<h4 class="text-primary m-4"><strong><?php echo e($doctor->drname); ?></strong></h4>
	        		<p class="text-secondary ml-4"><strong><?php echo e($doctor->experience); ?> Years of Experience</strong></p>
	        		<p class="text-secondary ml-4"><strong>Accepting New Patients: <?php echo e($doctor->accepting); ?></strong></p>
	        	</div>
	        </div>

	        <hr>

	        <div>
	        	<p class="text-primary ml-4"><strong>About Dr. <?php echo e($doctor->drname); ?></strong></p>
	        	<div>
	        		<p class="ml-4" style="text-align:justify;"><?php echo e($doctor->aboutdr); ?></p>
	        	</div>
	        </div>
    	
    	<!-- Chamber Locations -->
		<div>
	    	<p class="text-primary ml-4"><strong>Chamber Locations</strong></p>

	    	<?php $__currentLoopData = $chambers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chamber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<p class="text-secondary ml-4"><strong>Chamber Name: </strong> <mark><?php echo e($chamber->chambername); ?></mark></p>
            	<p class="text-secondary ml-4"><strong>Phone: </strong> <mark><?php echo e($chamber->telephone); ?></mark></p>
            	<p class="text-secondary ml-4"><mark><?php echo e($chamber->zip); ?>, <?php echo e($chamber->city); ?></mark></p>
            	<p class="text-secondary ml-4"><mark><?php echo e($chamber->city); ?>, <?php echo e($chamber->state); ?></mark></p>
            	<p class="text-secondary ml-4"><strong>Accepting New Patients: </strong><mark><?php echo e($chamber->accepting); ?></mark></p>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </div>

	    <hr>

	    <!-- Hospital Affliations -->
	    <div>
	    	<p class="text-primary ml-4"><strong>Hospital Affliations</strong></p>

	    	<?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<p class="text-secondary ml-4"><strong>Hospital Name: </strong> <mark><?php echo e($hospital->hospitalname); ?></mark></p>
            	<p><a class="text-secondary ml-4" style="text-decoration: none;" href="<?php echo e($hospital->url); ?>"><strong>URL: </strong> <mark><?php echo e($hospital->url); ?></mark></a></p>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </div>

	    <hr>

	    <!-- Education -->
	    <div>
	    	<p class="text-primary ml-4"><strong>Educations</strong></p>

	    	<?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<p class="text-secondary ml-4"><strong>Institution Name: </strong> <mark><?php echo e($education->institution); ?></mark></p>
            	<p class="text-secondary ml-4"><strong>Graduated in: </strong> <mark><?php echo e($education->gyear); ?></mark></p>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </div>

	    <hr>

	    <!-- Insurances -->
	    <div>
	    	<p class="text-primary ml-4"><strong>Insurances</strong></p>

	    	<?php $__currentLoopData = $insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    		<p class="text-secondary ml-4"><strong>Insurance Name: </strong> <mark><?php echo e($insurance->name); ?></mark></p>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </div>

	    <hr>

	    <!-- Awards -->
	    <div class="pb-2">
	    	<p class="text-primary ml-4"><strong>Awards</strong></p>

	    	<?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<p class="text-secondary ml-4"><strong>Award Name: </strong> <mark><?php echo e($award->name); ?></mark></p>
            	<p class="text-secondary ml-4"><strong>Award Description: </strong> <mark><?php echo e($award->description); ?></mark></p>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </div>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('specialist_doctors_bd.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Noyan\Specialist_Doctors_Bangladesh\resources\views/specialist_doctors_bd/specialist_doctors/specialist_doctor_profile.blade.php ENDPATH**/ ?>