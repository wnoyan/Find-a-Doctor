

<?php $__env->startSection('content'); ?>

    <div class="container shadow-lg mb-2 p-2 bg-white">

    	<div class=" text-success p-2 mb-2">
        	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	          		<p>Post ID: <?php echo e($post->id); ?></p>
	          		<p>Post Title: <?php echo e($post->title); ?></p>
	          	<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	          		<p>Tag ID: <?php echo e($tag->id); ?></p>
	          		<p>Tag Name: <?php echo e($tag->name); ?></p>
	        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    	<div class="row text-success p-2 mb-2">
        	<div class="col">
           		<h4 style="text-align:center;">Write Blog!</h4>
        	</div>
        </div>

	    <form action="<?php echo e(route('blog')); ?>" method="POST" enctype="multipart/form-data" class="was-validated">
	        <?php echo e(csrf_field()); ?>

	          
	        <div class="form-group">
	          <label for="title">Blog Title:</label>
	          <input type="text" class="form-control" id="title" placeholder="Ex: How to Live Long!" name="title" required>
	          <div class="valid-feedback">Valid.</div>
	          <div class="invalid-feedback">Please fill out this field.</div>
	        </div>

	        <!-- <div class="form-group">
	          <label for="">Category:</label>
	          <select class="form-control select2" name="category" required>
	          	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	          		<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
	          	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	          </select>
	          <div class="valid-feedback">Valid.</div>
	          <div class="invalid-feedback">Please fill out this field.</div>
	        </div> -->

	        <div class="form-group">
	        	<label for="category">Category:</label>
		        <input class="form-control" list="category" name="category" required>

				<datalist id="category">
				  <option value="Internet Explorer">
				  <option value="Firefox">
				  <option value="Chrome">
				  <option value="Opera">
				  <option value="Safari">
				</datalist>
			</div>

	        <div class="form-group">
	          <label for="">Tags:</label>
	          <select class="form-control select2-multi" name="tags[]" multiple required>
	          	<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	          		<option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
	          	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	          </select>
	          <div class="valid-feedback">Valid.</div>
	          <div class="invalid-feedback">Please fill out this field.</div>
	        </div>

	        <button type="submit" class="btn btn-primary">Submit</button>

	    </form>

	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script>
		$('.select2').select2();
		$('.select2-multi').select2();
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('specialist_doctors_bd.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Noyan\Specialist_Doctors_Bangladesh\resources\views/specialist_doctors_bd/blog/blog.blade.php ENDPATH**/ ?>