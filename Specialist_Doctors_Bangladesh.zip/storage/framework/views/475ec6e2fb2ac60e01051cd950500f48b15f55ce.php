

<?php $__env->startSection('content'); ?>
	
    <div class="container shadow-lg mb-2 bg-white">

        <div class="row text-success p-2">
        	<div class="col">
           		<h4 style="text-align:center;">Chambers in ZIP - <?php echo e($zip); ?></h4>
        	</div>
        </div>

        <div>
	    	<p class="text-primary ml-4"><strong>Chamber Locations</strong></p> <hr>

	    	<?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chamber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<p class="text-secondary ml-4"><strong>Chamber Name: </strong> <mark><?php echo e($chamber->chambername); ?></mark></p>
            	<p class="text-secondary ml-4"><strong>Phone: </strong> <mark><?php echo e($chamber->telephone); ?></mark></p>
            	<p class="text-secondary ml-4"><mark><?php echo e($chamber->zip); ?>, <?php echo e($chamber->city); ?></mark></p>
            	<p class="text-secondary ml-4"><mark><?php echo e($chamber->city); ?>, <?php echo e($chamber->state); ?></mark></p>
            	<p class="text-secondary ml-4"><strong>Accepting New Patients: </strong><mark><?php echo e($chamber->accepting); ?></mark></p>

                <hr>

        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </div>

        <div class="row pagination justify-content-center">
            <li class="page-item"><?php echo e($doctors->links()); ?></li>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('specialist_doctors_bd.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Noyan\Specialist_Doctors_Bangladesh\resources\views/specialist_doctors_bd/searching/zipsearching.blade.php ENDPATH**/ ?>