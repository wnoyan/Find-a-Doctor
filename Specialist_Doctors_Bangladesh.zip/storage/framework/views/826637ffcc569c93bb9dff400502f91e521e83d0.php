

<?php $__env->startSection('content'); ?>
	
	<h3>I am Normal Page!</h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Noyan\Specialist_Doctors_Bangladesh\resources\views/student/normal.blade.php ENDPATH**/ ?>