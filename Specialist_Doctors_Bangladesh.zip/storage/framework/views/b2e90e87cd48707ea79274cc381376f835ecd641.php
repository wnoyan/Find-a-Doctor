<div class="container-fluid footer">
        <div class="row">
            <div class="col-3 bg-light ml-4">
                <div class="row">
                    <div class="col-3">
                        <a href="https://twitter.com/home"><i class="fa fa-twitter"></i></a>
                    </div>
                    <div class="col-3">
                        <a href="https://web.facebook.com/wnoyan/"><i class="fa fa-facebook-f"></i></a>
                    </div>
                    <div class="col-3">
                        <a href="#"><i class="fa fa-google-plus"></i></a>
                    </div>
                    <div class="col-3">
                        <a href="https://www.linkedin.com/feed/"><i class="fa fa-linkedin"></i></a>
                    </div>
                </div>
            </div>
            
            <div class="col-8">
                <nav class="navbar navbar-expand-sm justify-content-center">
                  <ul class="navbar-nav">
                    <li class="nav-item">
                      <a class="nav-link" href="#">Advertise</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">About Us</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">Privacy Policy</a>
                        <li class="nav-item">
                      <a class="nav-link" href="#">Contact</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">Donate</a>
                    </li>
                    </li>
                  </ul>
                </nav>
            </div>
            
        </div>
    </div><?php /**PATH C:\xampp\htdocs\Noyan\Specialist_Doctors_Bangladesh\resources\views/specialist_doctors_bd/layout/footer.blade.php ENDPATH**/ ?>