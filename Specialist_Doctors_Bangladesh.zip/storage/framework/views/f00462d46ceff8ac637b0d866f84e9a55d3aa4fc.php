

<?php $__env->startSection('content'); ?>
	
	<!--Search Doctor Starting-->
    <div class="container shadow-lg mb-2 bg-white body-search">
        <p class="ml-2">Find The Best Doctor Right Fit For You
</p>
        <div class="row">
            <div class="col ml-2">
                <form class="form-inline" action="#">
                    <span class="fas fa-search p-2"></span>
                    
                    <input type="text" class="form-control" id="speciality" placeholder="Speciality" name="speciality">
                    
                    <input type="text" class="form-control" id="city-state" placeholder="City, State or Zip" name="city-state">
                    
                    <input type="text" class="form-control" id="name" placeholder="Doctor's Name" name="name">
    
                    <button type="submit" class="btn">Search</button>
                </form>
            </div>
        </div>
    </div>
    <!--Search Doctor Closing-->
      
    <!--Specialist Doctors Starting-->
    <div class="container shadow-lg mb-2 bg-white body-speciality">
        <h3>Specialist Doctors</h3>
        <div class="row row-cols-4 pb-4">
            <div class="col-3">
                <a href="#">Allergy & Immunology</a>
            </div>
            <div class="col-3">
                <a href="#">Dermatology</a>
            </div>
            <div class="col-3">
                <a href="#">Gastroenterology</a>
            </div>
            <div class="col-3">
                <a href="#">Neuromedicine</a>
            </div>
        </div>
        <div class="row row-cols-4 pb-4">
            <div class="col-3">
                <a href="#">Burn & Plastic</a>
            </div>
            <div class="col-3">
                <a href="#">ENT</a>
            </div>
            <div class="col-3">
                <a href="#">Hematology</a>
            </div>
            <div class="col-3">
                <a href="#">Oncology</a>
            </div>
        </div>
        <div class="row row-cols-4 pb-4">
            <div class="col-3">
                <a href="/cardiology">Cardiology</a>
            </div>
            <div class="col-3">
                <a href="#">Family Medicine</a>
            </div>
            <div class="col-3">
                <a href="#">Infertility</a>
            </div>
            <div class="col-3">
                <a href="#">Urology</a>
            </div>
        </div>
    </div>
    <!--Specialist Doctors Starting-->
      
    <!--Select Area Starting-->
    <div class="container shadow-lg mb-2 bg-white body-area">
        <h3>Doctors By Location</h3>
        <div class="row row-cols-4 pb-4">
            <div class="col-3">
                <a href="#">Atlana</a>
            </div>
            <div class="col-3">
                <a href="#">Dallas</a>
            </div>
            <div class="col-3">
                <a href="#">Miami</a>
            </div>
            <div class="col-3">
                <a href="#">San Diego</a>
            </div>
        </div>
        <div class="row row-cols-4 pb-4">
            <div class="col-3">
                <a href="#">Boston</a>
            </div>
            <div class="col-3">
                <a href="#">Houston</a>
            </div>
            <div class="col-3">
                <a href="#">New Work</a>
            </div>
            <div class="col-3">
                <a href="#">Tucson</a>
            </div>
        </div>
        <div class="row row-cols-4 pb-4">
            <div class="col-3">
                <a href="#">Chicago</a>
            </div>
            <div class="col-3">
                <a href="#">Los Angeles</a>
            </div>
            <div class="col-3">
                <a href="#">Phoenix</a>
            </div>
            <div class="col-3">
                <a href="#">Washington, DC</a>
            </div>
        </div>
    </div>
    <!--Select Area Closing-->
      
    <!--Videos Area Starting-->
    <div class="container shadow-lg mb-2 bg-white body-video">
        <h4 class="ml-2">VIDEOS
</h4>
        <div class="row row-cols-xs-1 row-cols-sm-2 row-cols-xl-4">
            <div class="col-3">
                <iframe width="250" height="200" src="https://www.youtube.com/embed/M53Ug-OTOK8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                
                <p>Animation Video</p>
            </div>
            <div class="col-3">
                <iframe width="250" height="200" src="https://www.youtube.com/embed/M53Ug-OTOK8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                
                <p>Animation Video</p>
            </div>
            <div class="col-3">
                <iframe width="250" height="200" src="https://www.youtube.com/embed/M53Ug-OTOK8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                
                <p>Animation Video</p>
            </div>
            <div class="col-3">
                <iframe width="250" height="200" src="https://www.youtube.com/embed/M53Ug-OTOK8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                
                <p>Animation Video</p>
            </div>
        </div>
    </div>
    <!--Videos Area Closing-->
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('specialist_doctors_bd.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Noyan\Specialist_Doctors_Bangladesh\resources\views/specialist_doctors_bd/layout/home2.blade.php ENDPATH**/ ?>