

<?php $__env->startSection('content'); ?>
    
    <p>Blog</p>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('specialist_doctors_bd.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Noyan\Specialist_Doctors_Bangladesh\resources\views/specialist_doctors_bd/layout/blog.blade.php ENDPATH**/ ?>