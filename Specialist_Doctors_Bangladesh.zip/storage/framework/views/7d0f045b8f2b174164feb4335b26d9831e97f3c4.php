

<?php $__env->startSection('content'); ?>

    <div class="container shadow-lg mb-2 bg-white">
        <div class="row text-success p-2">
        	<div class="col">
           		<h4 style="text-align:center;">Searching Result for Dr <?php echo e($name); ?></h4>
        	</div>
        </div>


        <div class="row row-cols-2 mb-2">

        	<?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col mb-3">
            	<div class="card">
    				<img class="card-img-top rounded-circle mx-auto" src="<?php echo e(asset('image/doctor/' . $doctor->image)); ?>" style="width:50%; height:40%;" alt="Doctor Image">

    				<div class="card-body mx-auto">
                    	<p class="card-title">Doctor Name: <?php echo e($doctor->drname); ?></p>
                    	<p class="card-text">Doctor ID: <?php echo e($doctor->id); ?></p>
      					
      					<a href="<?php echo e(route('specialist_doctor_profile',$doctor->id)); ?>" class="btn btn-primary stretched-link">See Profile</a>
    				</div>
  				</div>
  			</div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        

        <div class="row pagination justify-content-center">
            <li class="page-item"><?php echo e($doctors->links()); ?></li>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('specialist_doctors_bd.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Noyan\Specialist_Doctors_Bangladesh\resources\views/specialist_doctors_bd/searching/namesearching.blade.php ENDPATH**/ ?>