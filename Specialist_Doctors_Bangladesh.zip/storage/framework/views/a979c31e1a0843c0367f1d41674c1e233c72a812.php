

<?php $__env->startSection('content'); ?>
	
	<div class="container shadow-lg mb-2 bg-white body-speciality">
        <div class="text-primary row justify-content-center pb-2">
            <h4>Cities <!-- In New York -->, USA</h4>
        </div>

        <div class="row row-cols-3 pb-4">
            <div class="col-4">
            	<?php $__currentLoopData = $citys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<a href="#"><?php echo e($city->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('specialist_doctors_bd.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Noyan\Specialist_Doctors_Bangladesh\resources\views/specialist_doctors_bd/specialist_doctors/location/generalstate.blade.php ENDPATH**/ ?>